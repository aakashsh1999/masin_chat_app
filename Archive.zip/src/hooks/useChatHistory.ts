import { useState, useEffect, useCallback } from "react";
import { v4 as uuidv4 } from "uuid";
import { Chat, Message } from "@/lib/types";

// A constant key for accessing localStorage
const CHAT_HISTORY_KEY = "chatHistory";

/**
 * A custom hook to manage the chat history in localStorage.
 * It handles creating, reading, updating, and deleting chats.
 */
export const useChatHistory = () => {
  // State to hold the chat history array
  const [history, setHistory] = useState<Chat[]>([]);
  // State to track if the history has been loaded from localStorage
  const [isLoaded, setIsLoaded] = useState(false);

  // Effect to load chat history from localStorage when the hook is first used
  useEffect(() => {
    try {
      const storedHistory = localStorage.getItem(CHAT_HISTORY_KEY);
      if (storedHistory) {
        setHistory(JSON.parse(storedHistory));
      }
    } catch (error) {
      console.error("Failed to load chat history from localStorage", error);
    }
    // Set isLoaded to true after attempting to load, so the app knows it can proceed
    setIsLoaded(true);
  }, []); // The empty dependency array [] ensures this runs only once on mount

  // A stable function to create a new chat
  const createNewChat = useCallback((): Chat => {
    const newChat: Chat = {
      id: uuidv4(),
      title: "New Chat",
      messages: [],
    };

    // Use the "functional update" form of setState.
    // This allows us to get the previous state without listing `history` as a dependency,
    // which makes this function stable and prevents re-renders.
    setHistory((prevHistory) => {
      const newHistory = [newChat, ...prevHistory];
      try {
        localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(newHistory));
      } catch (error) {
        console.error("Failed to save new chat to localStorage", error);
      }
      return newHistory;
    });

    return newChat;
  }, []); // Empty dependency array means this function never changes

  // A stable function to update an existing chat's messages and title
  const updateChat = useCallback(
    (chatId: string, updatedMessages: Message[]) => {
      setHistory((prevHistory) => {
        // Find the chat that needs updating
        const chatToUpdate = prevHistory.find((c) => c.id === chatId);
        if (!chatToUpdate) return prevHistory; // If not found, return the old history

        // Automatically set the title from the first user message
        const userMessage = updatedMessages.find((m) => m.role === "user");
        const newTitle = userMessage
          ? userMessage.content.substring(0, 35) +
            (userMessage.content.length > 35 ? "..." : "")
          : chatToUpdate.title;

        // Create the updated chat object
        const updatedChat: Chat = {
          ...chatToUpdate,
          messages: updatedMessages,
          title: newTitle,
        };

        // Create the new history array
        const newHistory = prevHistory.map((c) =>
          c.id === chatId ? updatedChat : c
        );

        try {
          localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(newHistory));
        } catch (error) {
          console.error("Failed to update chat in localStorage", error);
        }

        return newHistory;
      });
    },
    [] // Empty dependency array means this function never changes
  );

  // A stable function to delete a chat by its ID
  const deleteChat = useCallback((chatId: string) => {
    setHistory((prevHistory) => {
      const newHistory = prevHistory.filter((c) => c.id !== chatId);
      try {
        localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(newHistory));
      } catch (error) {
        console.error("Failed to delete chat from localStorage", error);
      }
      return newHistory;
    });
  }, []); // Empty dependency array means this function never changes

  // getChatById can depend on `history` as it's a read-only operation
  // and needs the latest data.
  const getChatById = useCallback(
    (chatId: string): Chat | undefined => {
      return history.find((c) => c.id === chatId);
    },
    [history]
  );

  // Return all the state values and functions for components to use
  return {
    history,
    isLoaded,
    createNewChat,
    updateChat,
    getChatById,
    deleteChat,
  };
};
