"use client";

import { useEffect, useRef, useState } from "react";
import { useChatHistory } from "@/hooks/useChatHistory";
import { Message } from "@/lib/types";
import SystemPrompt from "./SystemPrompt";
import { useChat } from "@/context/ChatProvider";
import UserPrompt from "./UserPrompt";
// Corrected import path from 'context' to 'contexts'
import { PaperAirplaneIcon } from "@heroicons/react/24/solid";

type ChatInterfaceProps = {
  chatId: string;
};

export default function ChatInterface({ chatId }: ChatInterfaceProps) {
  const {
    messages,
    setMessages,
    isLoading,
    setIsLoading,
    streamedResponse,
    setStreamedResponse,
    isStreaming,
    setIsStreaming,
  } = useChat();
  const { getChatById, updateChat } = useChatHistory();
  const [input, setInput] = useState("");
  const chatLogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const chat = getChatById(chatId);
    if (chat) {
      setMessages(chat.messages);
    } else {
      setMessages([]);
    }
    setStreamedResponse("");
    setIsLoading(false);
    setIsStreaming(false); // Ensure streaming is reset on chat change
  }, [
    chatId,
    getChatById,
    setMessages,
    setStreamedResponse,
    setIsLoading,
    setIsStreaming,
  ]);

  useEffect(() => {
    chatLogRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, streamedResponse]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading || isStreaming) return;

    const newUserMessage: Message = { role: "user", content: input };
    const updatedMessages = [...messages, newUserMessage];
    setMessages(updatedMessages);
    setInput("");
    setIsLoading(true);
    setIsStreaming(true);
    let timeoutId: NodeJS.Timeout | null = null;

    try {
      // Set a 15-second timeout for the entire operation
      timeoutId = setTimeout(() => {
        timeoutId = null; // Prevent clearing a timeout that has already fired
        const errorMessage: Message = {
          role: "model",
          content:
            "The server is taking too long to respond. Please check your connection or API key and try again.",
        };
        // Update messages and save to history
        const finalErrorMessages = [...updatedMessages, errorMessage];
        setMessages(finalErrorMessages);
        updateChat(chatId, finalErrorMessages);
        // Reset loading states
        setIsLoading(false);
        setIsStreaming(false);
        setStreamedResponse("");
      }, 15000);

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ history: updatedMessages }),
      });

      // If we got a response, clear the timeout
      if (timeoutId) clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
      }

      if (!response.body) {
        throw new Error("Response body is null");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let completeResponse = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        completeResponse += chunk;
        setStreamedResponse((prev) => prev + chunk);
      }

      const finalMessages = [
        ...updatedMessages,
        { role: "model" as const, content: completeResponse },
      ];
      setMessages(finalMessages);
      updateChat(chatId, finalMessages);
    } catch (error) {
      if (timeoutId) clearTimeout(timeoutId); // Clear timeout on error too
      console.error("Error fetching chat response:", error);
      const errorMessage: Message = {
        role: "model",
        content: "Sorry, I encountered an error. Please try again.",
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setIsStreaming(false);
      setStreamedResponse("");
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-gray-900">
      <div
        ref={chatLogRef}
        className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide"
      >
        {messages.map((msg, index) =>
          msg.role === "user" ? (
            <UserPrompt
              key={`${chatId}-user-${index}`}
              chatPrompt={msg.content}
            />
          ) : (
            <SystemPrompt
              key={`${chatId}-model-${index}`}
              botMessage={msg.content}
            />
          )
        )}
        {isStreaming && (
          <SystemPrompt botMessage={streamedResponse} isStreaming={true} />
        )}
      </div>
      <div className="p-4 bg-gray-800/50 border-t border-gray-700">
        <form
          onSubmit={handleSubmit}
          className="flex items-center max-w-4xl mx-auto"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message here..."
            className="flex-1 p-3 bg-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading || isStreaming}
          />
          <button
            type="submit"
            className="ml-3 p-3 bg-blue-600 rounded-lg disabled:bg-gray-500 hover:bg-blue-700"
            disabled={isLoading || isStreaming || !input.trim()}
          >
            <PaperAirplaneIcon className="w-6 h-6 text-white" />
          </button>
        </form>
      </div>
    </div>
  );
}
