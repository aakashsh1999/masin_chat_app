"use client";

import { useChatHistory } from "@/hooks/useChatHistory";
import { PlusIcon, TrashIcon } from "@heroicons/react/24/outline";
import Link from "next/link";
import { useRouter, useParams } from "next/navigation";

export default function Sidebar() {
  const { history, createNewChat, deleteChat, isLoaded } = useChatHistory();
  const router = useRouter();
  const params = useParams();
  const activeChatId = params.id;

  const handleNewChat = () => {
    const newChat = createNewChat();
    router.push(`/chat/${newChat.id}`);
  };

  const handleDelete = (e: React.MouseEvent, chatId: string) => {
    e.preventDefault();
    e.stopPropagation();
    deleteChat(chatId);
    if (activeChatId === chatId) {
      router.push("/");
    }
  };

  return (
    <div className="w-64 bg-gray-800 p-4 flex flex-col">
      <button
        onClick={handleNewChat}
        className="flex items-center justify-center gap-2 w-full px-4 py-2 mb-4 text-white bg-blue-600 rounded-md hover:bg-blue-700"
      >
        <PlusIcon className="w-5 h-5" />
        New Chat
      </button>
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        <h2 className="text-xs font-semibold text-gray-400 mb-2">
          Chat History
        </h2>
        {isLoaded && history.length > 0 ? (
          <ul>
            {history.map((chat) => (
              <li key={chat.id} className="mb-2">
                <Link
                  href={`/chat/${chat.id}`}
                  className={`flex justify-between items-center w-full text-left p-2 rounded-md text-sm ${
                    activeChatId === chat.id
                      ? "bg-gray-700"
                      : "hover:bg-gray-700/50"
                  }`}
                >
                  <span className="truncate flex-1">{chat.title}</span>
                  <button
                    onClick={(e) => handleDelete(e, chat.id)}
                    className="ml-2 p-1 rounded-full hover:bg-gray-600"
                  >
                    <TrashIcon className="w-4 h-4 text-gray-400" />
                  </button>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-gray-500">No chats yet.</p>
        )}
      </div>
    </div>
  );
}
