import React from "react";

function UserPrompt({ chatPrompt }: { chatPrompt: string }) {
  return (
    <div className="flex items-start w-full mb-4 justify-end">
      <div className="max-w-xl bg-blue-600 text-white px-4 py-3 rounded-lg">
        {chatPrompt}
      </div>
      <div className="flex justify-center items-center bg-gray-600 text-white rounded-full ml-3 w-10 h-10 flex-shrink-0">
        U
      </div>
    </div>
  );
}

export default UserPrompt;
