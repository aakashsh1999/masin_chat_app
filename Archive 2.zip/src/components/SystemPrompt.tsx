"use client";
import React, { useState, useEffect, useRef } from "react";
import PulseLoader from "react-spinners/PulseLoader";

interface SystemPromptProps {
  botMessage: string;
  isStreaming?: boolean;
}

function SystemPrompt({ botMessage, isStreaming = false }: SystemPromptProps) {
  const [displayedMessage, setDisplayedMessage] = useState("");
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  useEffect(() => {
    if (isStreaming) {
      setDisplayedMessage(botMessage);
    } else {
      setDisplayedMessage("");
      let index = 0;
      const interval = setInterval(() => {
        if (!isMounted.current) {
          clearInterval(interval);
          return;
        }
        setDisplayedMessage((prev) => prev + botMessage[index]);
        index++;
        if (index >= botMessage.length) {
          clearInterval(interval);
        }
      }, 20); // Typing speed

      return () => clearInterval(interval);
    }
  }, [botMessage, isStreaming]);

  const isEmpty =
    botMessage === undefined || botMessage === null || botMessage === "";

  return (
    <div className="flex items-start w-full mb-4">
      <img src="/ai_avatar.svg" alt="AI Avatar" className="w-10 h-10 mr-3.5" />
      <div className="w-full max-w-xl bg-gray-700 text-white px-4 py-3 rounded-lg">
        {isEmpty && !isStreaming ? (
          <PulseLoader color="white" size={8} />
        ) : (
          <>
            {isStreaming ? botMessage : displayedMessage}
            {isStreaming && (
              <span className="inline-block w-2 h-4 bg-white animate-pulse ml-1" />
            )}
          </>
        )}
      </div>
    </div>
  );
}

// Add a default svg to the public folder if it doesn't exist
// public/ai_avatar.svg
export default SystemPrompt;
